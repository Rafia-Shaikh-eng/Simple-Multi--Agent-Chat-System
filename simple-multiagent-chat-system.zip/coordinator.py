from utils import logger, now_ts, write_output
from memory import MemoryAgent
from agents import ResearchAgent, AnalysisAgent
class Coordinator:
    def __init__(self, memory=None):
        self.memory = memory or MemoryAgent()
        self.research = ResearchAgent(self.memory)
        self.analysis = AnalysisAgent(self.memory)
        self.log = logger
    def _log_call(self, agent_name, message):
        self.log.debug(f'Coordinator -> {agent_name}: {message}')
    def handle_query(self, user_query):
        q = user_query.strip()
        plan = self._plan(q)
        self.log.info(f'Coordinator: plan for query "{q}" -> {plan}')
        outputs = {'query':q,'plan':plan,'steps':[], 'timestamp': now_ts()}
        research_results = []
        analysis_results = []
        try:
            if 'research' in plan:
                msg = {'type':'research','payload':{'query':q}, 'meta':{}}
                self._log_call('ResearchAgent', msg)
                rr = self.research.handle(msg)
                outputs['steps'].append(rr)
                research_results = rr['payload']['results']
            if 'analysis' in plan:
                items = research_results if research_results else [ {'title':'Memory pull','text':'','score':0.4} ]
                msg = {'type':'analyze','payload':{'task':plan.get('analysis_task','summarize'),'items':items}, 'meta':{}}
                self._log_call('AnalysisAgent', msg)
                ar = self.analysis.handle(msg)
                outputs['steps'].append(ar)
                analysis_results = ar['payload']
            merged = self._merge(research_results, analysis_results)
            outputs['merged'] = merged
            self.memory.add_record(topic=q, source='Coordinator', agent='Coordinator', confidence=merged.get('confidence',0.6), text=merged.get('answer',''))
            return outputs
        except Exception as e:
            self.log.exception('Coordinator encountered an error')
            return {'error':str(e)}
    def _plan(self, q):
        lowq = q.lower()
        plan = {}
        if '?' in q and any(k in lowq for k in ['what','who','when','which']):
            plan['research'] = True
            plan['analysis'] = True
            plan['analysis_task'] = 'summarize'
        elif any(k in lowq for k in ['compare','vs','versus','recommend']):
            plan['research'] = True
            plan['analysis'] = True
            plan['analysis_task'] = 'compare'
        elif 'analyze' in lowq or 'calculate' in lowq:
            plan['research'] = True
            plan['analysis'] = True
            plan['analysis_task'] = 'detailed'
        else:
            plan['research'] = True
            plan['analysis'] = False
        return plan
    def _merge(self, research_results, analysis_results):
        answer_parts = []
        confidence = 0.0
        for r in research_results:
            answer_parts.append(f"{r.get('title')}: {r.get('text')}")
            confidence = max(confidence, r.get('score',0.4))
        if 'summary' in analysis_results:
            answer_parts.append('Summary: ' + analysis_results['summary'])
            confidence = max(confidence, analysis_results.get('confidence',0.5))
        if 'comparison' in analysis_results:
            answer_parts.append('Comparison:\n' + analysis_results['comparison'])
            confidence = max(confidence, analysis_results.get('confidence',0.5))
        if 'analysis' in analysis_results:
            answer_parts.append('Analysis: ' + str(analysis_results['analysis']))
            confidence = max(confidence, analysis_results.get('confidence',0.5))
        answer = '\n\n'.join(answer_parts) if answer_parts else 'I have no useful information.'
        return {'answer':answer, 'confidence':round(float(confidence),3)}
