import math, re, collections
from utils import now_ts, logger
class MemoryAgent:
    def __init__(self):
        self.records = []
        self._id = 0
        self.inverted = collections.defaultdict(set)
    def add_record(self, topic, source, agent, confidence, text):
        rec = {'id': self._id, 'timestamp': now_ts(), 'topic': topic, 'source': source, 'agent': agent, 'confidence': float(confidence), 'text': text}
        self.records.append(rec)
        self._index(rec)
        self._id += 1
        logger.debug(f'MemoryAgent: added record {rec["id"]} topic={topic} agent={agent} conf={confidence}')
        return rec
    def _index(self, rec):
        words = self._tokenize(rec['text']) | self._tokenize(rec['topic']) | self._tokenize(rec['source'])
        for w in words:
            self.inverted[w].add(rec['id'])
    def _tokenize(self, text):
        if not text:
            return set()
        toks = re.findall(r"\\w+", text.lower())
        return set(toks)
    def keyword_search(self, query, topk=5):
        qtokens = self._tokenize(query)
        candidate_ids = set()
        for t in qtokens:
            candidate_ids |= self.inverted.get(t, set())
        results = []
        for rec in self.records:
            if rec['id'] in candidate_ids:
                overlap = len(qtokens & self._tokenize(rec['text']))
                score = overlap + rec['confidence']
                results.append( (score, rec) )
        results.sort(key=lambda x: x[0], reverse=True)
        return [r for s,r in results[:topk]]
    def _vec(self, text):
        toks = re.findall(r"\\w+", (text or '').lower())
        vec = {}
        for t in toks:
            vec[t] = vec.get(t,0) + 1
        return vec
    def _cosine(self, a, b):
        common = set(a.keys()) & set(b.keys())
        num = sum(a[t]*b[t] for t in common)
        na = math.sqrt(sum(v*v for v in a.values()))
        nb = math.sqrt(sum(v*v for v in b.values()))
        if na==0 or nb==0:
            return 0.0
        return num/(na*nb)
    def vector_search(self, query, topk=5):
        qv = self._vec(query)
        scores = []
        for rec in self.records:
            rv = self._vec(rec['text'])
            sim = self._cosine(qv, rv)
            blended = 0.7*sim + 0.3*(rec['confidence']/1.0)
            scores.append((blended, rec))
        scores.sort(key=lambda x: x[0], reverse=True)
        return [r for s,r in scores[:topk]]
    def retrieve_recent(self, n=5):
        return list(sorted(self.records, key=lambda r: r['timestamp'], reverse=True))[:n]
    def dump(self):
        return list(self.records)
