import logging, os, datetime
LOG_PATH = os.path.join(os.path.dirname(__file__), 'outputs', 'agent_log.txt')
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
logger = logging.getLogger('multiagent')
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(LOG_PATH)
fh.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
ch.setFormatter(formatter)
if not logger.handlers:
    logger.addHandler(fh)
    logger.addHandler(ch)
def now_ts():
    return datetime.datetime.utcnow().isoformat() + 'Z'
def write_output(filename, text):
    from pathlib import Path
    out_dir = Path(__file__).parent / 'outputs'
    out_dir.mkdir(exist_ok=True)
    path = out_dir / filename
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    logger.info(f'Wrote output: {path}')
    return str(path)
