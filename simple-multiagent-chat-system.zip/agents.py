import random, json
from utils import logger
class ResearchAgent:
    def __init__(self, memory, kb=None):
        self.memory = memory
        self.kb = kb or [
            {'title':'Neural Networks - overview','text':'Neural networks include CNNs, RNNs, MLPs, Autoencoders, and Transformers. They are used for pattern recognition.' , 'source':'mock_kb'},
            {'title':'Convolutional Neural Networks','text':'CNNs are used for images and spatial data. They use convolutional filters.', 'source':'mock_kb'},
            {'title':'Recurrent Neural Networks','text':'RNNs and LSTMs handle sequences and time-series.', 'source':'mock_kb'},
            {'title':'Transformers','text':'Transformers use attention mechanisms and are state-of-the-art in NLP and many modalities.', 'source':'mock_kb'},
            {'title':'Reinforcement Learning survey','text':'Reinforcement Learning (RL) includes policy gradient and Q-learning approaches.', 'source':'mock_kb'}
        ]
    def handle(self, message):
        q = message['payload'].get('query','').lower()
        logger.info(f'ResearchAgent: received query: {q}')
        results = []
        for item in self.kb:
            score = 0
            if q in item['title'].lower() or q in item['text'].lower():
                score += 0.6
            for tok in q.split():
                if tok in item['text'].lower() or tok in item['title'].lower():
                    score += 0.1
            if score>0:
                results.append({'title':item['title'],'text':item['text'],'source':item['source'],'score':min(1.0,score)})
        results = sorted(results, key=lambda r: r['score'], reverse=True)[:3]
        if not results:
            results = [{'title':'Generic answer','text':f'Limited KB: could not find detailed items for "{q}".', 'source':'generic', 'score':0.4}]
        for r in results:
            self.memory.add_record(topic=q, source=r['source'], agent='ResearchAgent', confidence=r.get('score',0.4), text=r['text'])
        return {'type':'research_result','payload':{'query':q,'results':results}, 'meta':{'agent':'ResearchAgent'}}
class AnalysisAgent:
    def __init__(self, memory):
        self.memory = memory
    def handle(self, message):
        task = message['payload'].get('task','summarize')
        items = message['payload'].get('items',[])
        logger.info(f'AnalysisAgent: task={task} items={len(items)}')
        if task=='summarize':
            texts = [it.get('text','') for it in items]
            summary = self._summarize(texts)
            conf = 0.8 if len(texts)>0 else 0.4
            self.memory.add_record(topic='summary', source='AnalysisAgent', agent='AnalysisAgent', confidence=conf, text=summary)
            return {'type':'analysis_result','payload':{'summary':summary,'confidence':conf}, 'meta':{'agent':'AnalysisAgent'}}
        elif task=='compare':
            comp = self._compare(items)
            conf = 0.75
            self.memory.add_record(topic='comparison', source='AnalysisAgent', agent='AnalysisAgent', confidence=conf, text=comp)
            return {'type':'analysis_result','payload':{'comparison':comp,'confidence':conf}, 'meta':{'agent':'AnalysisAgent'}}
        elif task=='detailed':
            analysis = self._detailed(items)
            conf = 0.7
            self.memory.add_record(topic='analysis', source='AnalysisAgent', agent='AnalysisAgent', confidence=conf, text=json.dumps(analysis))
            return {'type':'analysis_result','payload':{'analysis':analysis,'confidence':conf}, 'meta':{'agent':'AnalysisAgent'}}
        else:
            return {'type':'analysis_result','payload':{'summary':'Unknown task','confidence':0.0}, 'meta':{'agent':'AnalysisAgent'}}
    def _summarize(self, texts):
        parts = []
        for t in texts:
            s = t.split('.')
            if s and s[0].strip():
                parts.append(s[0].strip())
        if not parts:
            return 'No content to summarize.'
        return ' '.join(parts[:5])
    def _compare(self, items):
        lines = []
        for it in items:
            title = it.get('title','(no title)')
            text = it.get('text','')
            score = it.get('score',0.5)
            if 'image' in text.lower() or 'convolution' in text.lower():
                domain = 'vision'
            elif 'sequence' in text.lower() or 'lstm' in text.lower():
                domain = 'sequence'
            elif 'attention' in text.lower() or 'transformer' in text.lower():
                domain = 'nlp/general'
            else:
                domain = 'general'
            lines.append(f"- {title}: domain={domain}, heuristic_score={score}")
        return '\n'.join(lines)
    def _detailed(self, items):
        keywords = ['transformer','cnn','rnn','attention','policy','q-learning','reinforcement']
        counts = {k:0 for k in keywords}
        for it in items:
            t = it.get('text','').lower()
            for k in keywords:
                counts[k] += t.count(k)
        return counts
