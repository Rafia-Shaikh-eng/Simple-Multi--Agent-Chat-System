import json
from coordinator import Coordinator
from utils import write_output, logger
def run_query(coord, q):
    res = coord.handle_query(q)
    return res
def run_tests(coord):
    tests = [
        ('test1_simple','What are the main types of neural networks?'),
        ('test2_complex','Please research and analyze Transformers: architecture, strengths, and weaknesses.'),
        ('test3_memory','Remind me what we discussed about Transformers earlier.'),
        ('test4_multistep','Research recent reinforcement learning papers and provide a short analysis.'),
        ('test5_collaborative','Compare CNNs, RNNs, and Transformers and recommend which to use for image captioning.'),
    ]
    outputs = {}
    for name, q in tests:
        logger.info(f'Running {name}: {q}')
        out = run_query(coord, q)
        path = write_output(f"{name}.txt", json.dumps(out, indent=2))
        outputs[name] = {'query':q, 'output_path':path}
    mem_path = write_output('memory_dump.json', json.dumps(coord.memory.dump(), indent=2))
    outputs['memory_dump'] = mem_path
    print('\nTests complete. Outputs written to outputs/ directory.')
    return outputs
if __name__=='__main__':
    coord = Coordinator()
    run_tests(coord)
